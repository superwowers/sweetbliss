package SweetBliss;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class OrderListController {
    public static class OrderItem {
        public String itemName;
        public int quantity;
        public double pricePerPiece;

        public OrderItem(String itemName, int quantity, double pricePerPiece) {
            this.itemName = itemName;
            this.quantity = quantity;
            this.pricePerPiece = pricePerPiece;
        }
    }

    public static final ArrayList<OrderItem> orderItemsList = new ArrayList<>();

    public void addItem(OrderItem orderItem, JTextArea textArea, JTextField totalField) {
        for (OrderItem currentItem : orderItemsList){
            if (currentItem.itemName.equals(orderItem.itemName)){
                currentItem.quantity += orderItem.quantity;
                refreshUI(textArea, totalField);
                return;
            }
        }

        orderItemsList.add(orderItem);
        refreshUI(textArea, totalField);
    }

    public ArrayList<OrderItem> getItemList(){
        return(orderItemsList);
    }

    private final Locale currencyFormat = new Locale.Builder().setLanguage("en").setRegion("ph").build();
    private final NumberFormat numberFormat = NumberFormat.getCurrencyInstance(currencyFormat);

   public void refreshTextArea(JTextArea orderTextList){
        String tempString = "";
        String rowFormat = "%d %50s \t %s%n";
        for (OrderItem orderItem : orderItemsList){
            String row = String.format(rowFormat, orderItem.quantity, orderItem.itemName, numberFormat.format(orderItem.pricePerPiece * orderItem.quantity));
            tempString = tempString.concat(row);
        }   
        orderTextList.setText(tempString);
    } 

    public void refreshTotalField(JTextField totalTextField){
        double totalCost = 0;
        for (OrderItem orderItem : orderItemsList){
            totalCost += orderItem.pricePerPiece * orderItem.quantity;
        }
        totalTextField.setText("TOTAL: " + numberFormat.format(totalCost));
    } 

    public void refreshUI(JTextArea orderTextList, JTextField totalField) {
        refreshTextArea(orderTextList);
        refreshTotalField(totalField);
    }
}