/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SweetBliss;

/**
 *
 * @author lrnms
 */
public enum Prices {
    // Start of Coffee
    ESPRESSO(100),
    AMERICANO(160),
    LATTE(185),
    CAPPUCINO(170),
    MACCHIATO(195),
    BLACKTEA(100),
    GREENTEA(150),
    CHAMOMILETEA(175),
    OOLONGTEA(110),
    WHITETEA(150),
    CROSSAINT(145),
    CINNAMONBUN(145),
    MADELEINE(125),
    BAGUETTE(200),
    SUGARDUSTEDDONUT(50),
    VANILLAFROSTEDDONUT(70),
    CHOCOLATEGLAZEDDONUT(65),
    MAPLEGLAZEDDONUT(90),
    FRUITTART(155),
    LEMONTART(120),
    CARAMELNUTTART(200),
    COLDBREWTALL(75),
    COLDBREWGRANDE(95),
    COLDBREWVENTI(120),
    ICEDLATTETALL(95),
    ICEDLATTEGRANDE(150),
    ICEDLATTEVENTI(200),
    ICEDCARAMELMACCHIATOTALL(110),
    ICEDCARAMELMACCHIATOGRANDE(140),
    ICEDCARAMELMACCHIATOVENTI(200),
    ICEDMOCHATALL(75),
    ICEDMOCHAGRANDE(95),
    ICEDMOCHAVENTI(120),
    CHOCOLATECAKESLICE(230),
    CHOCOLATECAKEWHOLE(1500),
    VANILLASPONGECAKESLICE(200),
    VANILLASPONGECAKEWHOLE(1300),
    LEMONDRIZZLECAKESLICE(250),
    LEMONDRIZZLECAKEWHOLE(1700),
    BLUEBERRYCAKESLICE(250),
    BLUEBERRYCAKEWHOLE(1700);
   
   

    public double price;

    private Prices(double price) {
        this.price = price;
    }
}
